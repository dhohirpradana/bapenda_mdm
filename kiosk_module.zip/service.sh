#!/system/bin/sh
MODPATH=${0%/*}

# Start daemon on boot via Magisk
case "$1" in
  start)
    nohup sh $MODPATH/daemon.sh start >/dev/null 2>&1 &
    ;;
  stop)
    sh $MODPATH/daemon.sh stop
    ;;
  *)
    nohup sh $MODPATH/daemon.sh start >/dev/null 2>&1 &
    ;;
esac

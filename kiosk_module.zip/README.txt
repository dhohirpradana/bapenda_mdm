Kiosk Watchdog Magisk Module
============================

What it does
------------
This module provides a simple watchdog daemon (daemon.sh) that keeps a configured
target app on top by periodically checking the current foreground app and
bringing the target app to the front if needed.

Files
-----
- module.prop          : Magisk module descriptor
- service.sh           : Executed by Magisk on boot, starts daemon.sh
- daemon.sh            : Watchdog loop (runs as root)
- uninstall.sh         : Optional uninstall helper

Configuration
-------------
Create /data/adb/kiosk_config.json with content:
{
  "enabled": true,
  "target": "com.example.targetapp",
  "whitelist": ["com.android.systemui"]
}

- enabled: true/false
- target : package name to keep on top
- whitelist: optional array of packages allowed to be on top (daemon will ignore them)

Usage from Flutter (example)
----------------------------
# write config (requires root)
cat > /data/adb/kiosk_config.json <<'EOF'
{"enabled": true, "target": "com.example.targetapp"}
EOF
chown root:shell /data/adb/kiosk_config.json
chmod 660 /data/adb/kiosk_config.json

# start daemon (requires root)
sh /data/adb/modules/kiosk_module/daemon.sh start

# stop daemon
sh /data/adb/modules/kiosk_module/daemon.sh stop

Safety
------
- Test on a non-production device first.
- If the device becomes unresponsive, use ADB or TWRP to remove module folder /data/adb/modules/kiosk_module.

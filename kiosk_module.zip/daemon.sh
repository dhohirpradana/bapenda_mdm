#!/system/bin/sh
# daemon.sh - kiosk watchdog
MODPATH=${0%/*}
PIDFILE=/data/adb/kiosk_watchdog.pid
CONF=/data/adb/kiosk_config.json
LOGTAG=KIOSK_WD

log() {
  # use logcat if available, fallback to echo
  if command -v logcat >/dev/null 2>&1; then
    echo "$@" | logcat -t "$LOGTAG"
  else
    echo "$@"
  fi
}

run_cmd() {
  su -c "$1" 2>/dev/null || $1 2>/dev/null
}

start() {
  if [ -f "$PIDFILE" ]; then
    echo "already running"
    exit 0
  fi

  (
    echo $$ > $PIDFILE
    log "watchdog started (pid $$)"
    while true; do
      if [ ! -f "$CONF" ]; then
        sleep 2
        continue
      fi

      # read enabled and target, support simple json
      enabled=$(grep -o '"enabled"[[:space:]]*:[[:space:]]*[^,}]*' $CONF 2>/dev/null | sed 's/.*:[[:space:]]*//g' | tr -d ' "')
      target=$(grep -o '"target"[[:space:]]*:[[:space:]]*"[^"]*"' $CONF 2>/dev/null | sed 's/.*:[[:space:]]*"\(.*\)"/\1/')
      # support whitelist array (optional)
      whitelist=$(grep -o '"whitelist"[[:space:]]*:[[:space:]]*\[[^\]]*\]' $CONF 2>/dev/null | sed 's/.*:\\[\(.*\)\\]/\1/' | tr -d '"')

      if [ "$enabled" = "true" ] && [ -n "$target" ]; then
        # determine top package
        toppkg=""
        # try activity service
        dumpsys activity activities 2>/dev/null | grep mResumedActivity >/dev/null 2>&1 &&           toppkg=$(dumpsys activity activities 2>/dev/null | grep mResumedActivity | sed -n 's/.* \([a-zA-Z0-9_.]*\)\/.*$/\1/p' | head -n1)

        if [ -z "$toppkg" ]; then
          # fallback to window
          toppkg=$(dumpsys window windows 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp' | sed -n 's/.* \([a-zA-Z0-9_.]*\)\/.*$/\1/p' | head -n1)
        fi

        # strip possible empty
        toppkg=$(echo "$toppkg" | tr -d '\r\n')

        # check whitelist
        allowed="false"
        if [ -n "$whitelist" ]; then
          IFS=','; for w in $whitelist; do
            w=$(echo $w | tr -d '[:space:]')
            if [ "$w" = "$toppkg" ]; then
              allowed="true"
              break
            fi
          done
        fi

        if [ "$toppkg" != "$target" ] && [ "$allowed" != "true" ]; then
          log "top=$toppkg not target=$target -> bringing target to front"

          # try to resolve launch component
          LAUNCHCOMP=$(cmd package resolve-activity --brief $target 2>/dev/null | tail -n1)
          if [ -n "$LAUNCHCOMP" ]; then
            run_cmd "am start --user 0 -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -n $LAUNCHCOMP"
          else
            # fallback to monkey
            run_cmd "monkey -p $target -c android.intent.category.LAUNCHER 1"
          fi
        fi
      fi

      sleep 2
    done
  ) &
  disown
  echo $! > $PIDFILE
  echo "started"
}

stop() {
  if [ -f "$PIDFILE" ]; then
    pid=$(cat $PIDFILE)
    kill $pid 2>/dev/null || true
    rm -f $PIDFILE
    echo "stopped"
  else
    echo "not running"
  fi
}

status() {
  if [ -f "$PIDFILE" ]; then
    echo "running (pid $(cat $PIDFILE))"
  else
    echo "not running"
  fi
}

case "$1" in
  start) start ;;
  stop) stop ;;
  status) status ;;
  *) echo "usage: $0 {start|stop|status}" ;;
esac

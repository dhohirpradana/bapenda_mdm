#!/system/bin/sh
# Uninstall helper: stop daemon and remove files
PIDFILE=/data/adb/kiosk_watchdog.pid
if [ -f "$PIDFILE" ]; then
  pid=$(cat $PIDFILE)
  kill $pid 2>/dev/null || true
  rm -f "$PIDFILE"
fi
rm -f /data/adb/kiosk_config.json
echo "kiosk module uninstalled"
